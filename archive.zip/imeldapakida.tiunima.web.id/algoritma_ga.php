<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log_ga.txt');

/**
 * ALGORITMA GENETIKA - Penjadwalan Mata Pelajaran
 * SMAN 2 Toraja Utara
 * Versi 7 - REVISI SIDANG:
 * - Inisialisasi populasi DIKEMBALIKAN ke acak murni (buat_kromosom_acak),
 *   tidak lagi menghindari bentrok saat pembuatan populasi awal.
 *   Ini supaya operator GA (seleksi, crossover, mutasi) yang benar-benar
 *   bertugas menurunkan jumlah bentrok generasi demi generasi, bukan
 *   inisialisasi yang diam-diam sudah menyelesaikan semuanya.
 * - repair_konflik() tetap ada, tapi sekarang murni sebagai pembersih sisa
 *   bentrok kecil setelah GA selesai berevolusi (sesuai konsep hybrid GA
 *   dengan repair operator yang sudah dikutip di BAB IV).
 * - Ditambahkan $log_evolusi: mencatat fitness & bentrok terbaik di SETIAP
 *   generasi, disimpan ke tabel log_generasi_ga untuk bahan grafik
 *   konvergensi di BAB IV.
 * - Versi 8 - MULTI-RESTART: karena GA bersifat stokastik, satu kali proses
 *   evolusi kadang berhenti di local optimum yang berbeda-beda (teruji: dari
 *   3 percobaan dengan parameter identik, hasil bentrok = 0, 11, dan 15).
 *   Sekarang seluruh proses (inisialisasi -> evolusi -> repair) diulang
 *   sebanyak $num_restart kali dalam satu klik Generate, dan sistem otomatis
 *   memilih hasil dengan bentrok paling sedikit (fitness tertinggi) di antara
 *   semua percobaan itu sebelum disimpan ke database.
 * - Versi 9 - SELEKSI TURNAMEN: data log_generasi_ga menunjukkan bentrok
 *   awal populasi bisa mencapai ~1600an (skala data riil SMAN 2 Toraja Utara
 *   cukup besar), dan pada skala ini rumus fitness = 1/(1+bentrok) membuat
 *   nilai fitness antar kromosom nyaris identik, sehingga seleksi roulette
 *   wheel kehilangan daya bedanya (evolusi jalan di tempat, sisa bentrok
 *   yang besar akhirnya "dibereskan" oleh repair operator, bukan oleh GA
 *   itu sendiri). Diganti ke seleksi turnamen yang tidak bergantung pada
 *   besar-kecilnya beda fitness, hanya pada urutan relatifnya.
 */

include 'koneksi.php';
header('Content-Type: application/json');
set_time_limit(600);

// =============================================
// 0. VALIDASI num_restart
// =============================================
// (didefinisikan setelah parameter GA di bawah, letak komentar ini hanya
// penanda urutan baca kode)

// =============================================
// 1. AMBIL PARAMETER
// =============================================
$pop_size    = isset($_POST['pop_size'])    ? (int)$_POST['pop_size']     : 50;
$max_gen     = isset($_POST['max_gen'])     ? (int)$_POST['max_gen']      : 200;
$cross_rate  = isset($_POST['cross_rate'])  ? (float)$_POST['cross_rate'] : 0.8;
$mut_rate    = isset($_POST['mut_rate'])    ? (float)$_POST['mut_rate']   : 0.1;
$num_restart = isset($_POST['num_restart']) ? (int)$_POST['num_restart']  : 5;

// =============================================
// 2. AMBIL DATA DARI DATABASE
// =============================================
$semester = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM semester WHERE status='1' LIMIT 1"));
if (!$semester) {
    echo json_encode(['success' => false, 'message' => 'Tidak ada semester aktif!']);
    exit;
}
$id_semester = $semester['id_semester'];

$kelas_ids = [];
$ruang_ids = [];

$semua_slot_waktu = []; // tiap elemen: ['hari'=>.., 'id_jam'=>.., 'jam_ke'=>..]
$q = mysqli_query($conn, "SELECT id_jam, hari, jam FROM jam ORDER BY hari, jam ASC");
while ($r = mysqli_fetch_assoc($q)) {
    $semua_slot_waktu[] = [
        'hari'   => $r['hari'],
        'id_jam' => $r['id_jam'],
        'jam_ke' => $r['jam'],
    ];
}

$q = mysqli_query($conn, "SELECT id_kelas FROM kelas WHERE id_semester=$id_semester");
while ($r = mysqli_fetch_assoc($q)) $kelas_ids[] = $r['id_kelas'];

$q = mysqli_query($conn, "SELECT id_ruang FROM ruang_kelas");
while ($r = mysqli_fetch_assoc($q)) $ruang_ids[] = $r['id_ruang'];

$guru_mapel  = [];
$semua_mapel = [];

$q = mysqli_query($conn, "SELECT gp.id_guru, gp.id_pelajaran FROM guru_pelajaran gp INNER JOIN guru g ON gp.id_guru = g.id_guru");
while ($r = mysqli_fetch_assoc($q)) {
    $id_p = $r['id_pelajaran'];
    $id_g = $r['id_guru'];
    if (!isset($guru_mapel[$id_p])) $guru_mapel[$id_p] = [];
    $guru_mapel[$id_p][] = $id_g;
    if (!in_array($id_p, $semua_mapel)) $semua_mapel[] = $id_p;
}

$semua_guru = [];
$q = mysqli_query($conn, "SELECT id_guru FROM guru");
while ($r = mysqli_fetch_assoc($q)) $semua_guru[] = $r['id_guru'];

if (empty($semua_mapel)) {
    $q = mysqli_query($conn, "SELECT id_pelajaran FROM pelajaran");
    while ($r = mysqli_fetch_assoc($q)) $semua_mapel[] = $r['id_pelajaran'];
    foreach ($semua_mapel as $id_p) $guru_mapel[$id_p] = $semua_guru;
}

// =============================================
// 2b. AMBIL JAM_PER_MINGGU PER KELAS
// =============================================
$kelas_pelajaran = [];
$q = mysqli_query($conn, "SELECT id_kelas, id_pelajaran, jam_per_minggu FROM kelas_pelajaran WHERE jam_per_minggu > 0");
while ($r = mysqli_fetch_assoc($q)) {
    $kelas_pelajaran[$r['id_kelas']][] = [
        'id_pelajaran'   => $r['id_pelajaran'],
        'jam_per_minggu' => (int)$r['jam_per_minggu'],
    ];
}

if (empty($kelas_ids) || empty($semua_slot_waktu) || empty($ruang_ids) || empty($semua_mapel)) {
    echo json_encode(['success' => false, 'message' => 'Data master tidak lengkap!']);
    exit;
}

if (empty($kelas_pelajaran)) {
    echo json_encode(['success' => false, 'message' => 'Data kurikulum (kelas_pelajaran / jam_per_minggu) belum diisi! Silakan atur jam per minggu tiap mapel di menu Kurikulum terlebih dahulu.']);
    exit;
}

// =============================================
// 3. FUNGSI BANTU
// =============================================

function get_guru_for_mapel($id_pelajaran, $guru_mapel, $semua_guru) {
    if (isset($guru_mapel[$id_pelajaran]) && !empty($guru_mapel[$id_pelajaran])) {
        return $guru_mapel[$id_pelajaran];
    }
    return $semua_guru;
}

function bangun_daftar_instance_mapel($id_kelas, $kelas_pelajaran) {
    $instance_list = [];
    if (!isset($kelas_pelajaran[$id_kelas])) return $instance_list;

    foreach ($kelas_pelajaran[$id_kelas] as $mp) {
        for ($i = 0; $i < $mp['jam_per_minggu']; $i++) {
            $instance_list[] = $mp['id_pelajaran'];
        }
    }
    return $instance_list;
}

/**
 * [REVISI] INISIALISASI ACAK MURNI
 * Tiap instance mapel di tiap kelas langsung dikasih slot waktu, guru, dan
 * ruang SECARA ACAK dari seluruh opsi yang valid (guru tetap dari daftar
 * pengampu resmi mapel tsb -- itu aturan data, bukan target optimasi GA),
 * TANPA mengecek apakah slot itu sudah dipakai kelas/guru/ruang lain.
 * Konsekuensinya: populasi awal akan penuh bentrok, dan GA (seleksi,
 * crossover, mutasi) yang bertugas menurunkannya generasi demi generasi.
 */
function buat_kromosom_acak($kelas_ids, $kelas_pelajaran, $guru_mapel, $semua_guru, $semua_slot_waktu, $ruang_ids) {
    $kromosom = [];

    foreach ($kelas_ids as $id_kelas) {
        $mapel_list = bangun_daftar_instance_mapel($id_kelas, $kelas_pelajaran);

        foreach ($mapel_list as $id_pelajaran) {
            $slot      = $semua_slot_waktu[array_rand($semua_slot_waktu)];
            $guru_list = get_guru_for_mapel($id_pelajaran, $guru_mapel, $semua_guru);
            $id_guru   = $guru_list[array_rand($guru_list)];
            $id_ruang  = $ruang_ids[array_rand($ruang_ids)];

            $kromosom[] = [
                'id_kelas'     => $id_kelas,
                'id_pelajaran' => $id_pelajaran,
                'id_guru'      => $id_guru,
                'id_jam'       => $slot['id_jam'],
                'id_ruang'     => $id_ruang,
                'hari'         => $slot['hari'],
            ];
        }
    }
    return $kromosom;
}

function hitung_fitness($kromosom) {
    return 1.0 / (1.0 + hitung_bentrok($kromosom));
}

function hitung_bentrok($kromosom) {
    $bentrok = 0;
    $seen_guru  = [];
    $seen_ruang = [];
    $seen_kelas = [];

    foreach ($kromosom as $gen) {
        $key_guru  = $gen['id_guru']  . '_' . $gen['id_jam'] . '_' . $gen['hari'];
        $key_ruang = $gen['id_ruang'] . '_' . $gen['id_jam'] . '_' . $gen['hari'];
        $key_kelas = $gen['id_kelas'] . '_' . $gen['id_jam'] . '_' . $gen['hari'];

        if (isset($seen_guru[$key_guru]))   $bentrok++;
        if (isset($seen_ruang[$key_ruang])) $bentrok++;
        if (isset($seen_kelas[$key_kelas])) $bentrok++;

        $seen_guru[$key_guru]   = true;
        $seen_ruang[$key_ruang] = true;
        $seen_kelas[$key_kelas] = true;
    }

    return $bentrok;
}

function seleksi_roulette($populasi, $fitness_list) {
    $total = array_sum($fitness_list);
    if ($total == 0) return $populasi[array_rand($populasi)];
    $r   = (mt_rand() / mt_getrandmax()) * $total;
    $kum = 0;
    foreach ($populasi as $i => $k) {
        $kum += $fitness_list[$i];
        if ($kum >= $r) return $k;
    }
    return end($populasi);
}

/**
 * [REVISI] SELEKSI TURNAMEN
 * Dengan rumus fitness = 1/(1+bentrok), saat bentrok masih besar (ribuan),
 * nilai fitness antar kromosom jadi nyaris identik (misal 0.00061 vs
 * 0.00063) sehingga seleksi roulette wheel (proporsional fitness) kehilangan
 * daya bedanya -- efeknya seleksi jadi nyaris acak dan evolusi jalan di
 * tempat. Seleksi turnamen tidak bergantung pada BESAR beda fitness, hanya
 * pada URUTANNYA (siapa lebih baik dari yang lain dalam sampel acak kecil),
 * sehingga tekanan seleksi tetap ada bahkan saat bentrok masih tinggi.
 */
function seleksi_turnamen($populasi, $fitness_list, $ukuran_turnamen = 3) {
    $n = count($populasi);
    $terbaik_idx = mt_rand(0, $n - 1);
    for ($i = 1; $i < $ukuran_turnamen; $i++) {
        $idx = mt_rand(0, $n - 1);
        if ($fitness_list[$idx] > $fitness_list[$terbaik_idx]) {
            $terbaik_idx = $idx;
        }
    }
    return $populasi[$terbaik_idx];
}

function crossover($p1, $p2, $cross_rate) {
    if ((mt_rand() / mt_getrandmax()) > $cross_rate) return $p1;
    $len = count($p1);
    if ($len < 2) return $p1;
    $titik = mt_rand(1, $len - 1);
    return array_merge(array_slice($p1, 0, $titik), array_slice($p2, $titik));
}

function mutasi_smart($kromosom, $mut_rate, $guru_mapel, $semua_guru, $ruang_ids, $semua_slot_waktu) {
    foreach ($kromosom as $idx => &$gen) {
        if ((mt_rand() / mt_getrandmax()) >= $mut_rate) continue;

        $slot = $semua_slot_waktu[array_rand($semua_slot_waktu)];
        $guru_list = get_guru_for_mapel($gen['id_pelajaran'], $guru_mapel, $semua_guru);

        $gen['hari']    = $slot['hari'];
        $gen['id_jam']  = $slot['id_jam'];
        $gen['id_guru'] = $guru_list[array_rand($guru_list)];
        $gen['id_ruang']= $ruang_ids[array_rand($ruang_ids)];
    }
    return $kromosom;
}

/**
 * REPAIR PASCA-EVOLUSI (dipertahankan dari versi sebelumnya)
 * Dijalankan sekali di akhir evolusi GA, khusus untuk kromosom TERBAIK,
 * untuk membersihkan SISA bentrok yang belum sempat diselesaikan GA
 * dalam batas max_gen. Ini bagian yang sah dari pendekatan hybrid GA
 * dengan repair operator (lihat pembahasan BAB IV) -- selama GA sendiri
 * yang sudah bekerja menurunkan mayoritas bentrok lebih dulu.
 */
function repair_konflik($kromosom, $guru_mapel, $semua_guru, $ruang_ids, $semua_slot_waktu, $max_pass = 15) {
    for ($pass = 0; $pass < $max_pass; $pass++) {

        $used_guru  = [];
        $used_ruang = [];
        $used_kelas = [];
        foreach ($kromosom as $idx => $gen) {
            $kg = $gen['id_guru']  . '_' . $gen['hari'] . '_' . $gen['id_jam'];
            $kr = $gen['id_ruang'] . '_' . $gen['hari'] . '_' . $gen['id_jam'];
            $kk = $gen['id_kelas'] . '_' . $gen['hari'] . '_' . $gen['id_jam'];
            $used_guru[$kg][]  = $idx;
            $used_ruang[$kr][] = $idx;
            $used_kelas[$kk][] = $idx;
        }

        $idx_bentrok = [];
        foreach ($used_guru as $list)  if (count($list) > 1) foreach (array_slice($list, 1) as $i) $idx_bentrok[$i] = true;
        foreach ($used_ruang as $list) if (count($list) > 1) foreach (array_slice($list, 1) as $i) $idx_bentrok[$i] = true;
        foreach ($used_kelas as $list) if (count($list) > 1) foreach (array_slice($list, 1) as $i) $idx_bentrok[$i] = true;

        if (empty($idx_bentrok)) break;

        $ada_perbaikan = false;

        foreach (array_keys($idx_bentrok) as $idx) {
            $gen = $kromosom[$idx];

            $kg_old = $gen['id_guru']  . '_' . $gen['hari'] . '_' . $gen['id_jam'];
            $kr_old = $gen['id_ruang'] . '_' . $gen['hari'] . '_' . $gen['id_jam'];
            $kk_old = $gen['id_kelas'] . '_' . $gen['hari'] . '_' . $gen['id_jam'];

            $used_guru[$kg_old]  = array_diff($used_guru[$kg_old] ?? [], [$idx]);
            $used_ruang[$kr_old] = array_diff($used_ruang[$kr_old] ?? [], [$idx]);
            $used_kelas[$kk_old] = array_diff($used_kelas[$kk_old] ?? [], [$idx]);

            $slot_acak = $semua_slot_waktu;
            shuffle($slot_acak);

            $guru_utama = get_guru_for_mapel($gen['id_pelajaran'], $guru_mapel, $semua_guru);
            $found = false;

            foreach ([$guru_utama, $semua_guru] as $daftar_guru) {
                if ($found) break;
                foreach ($slot_acak as $slot) {
                    $hari_baru = $slot['hari'];
                    $jam_baru  = $slot['id_jam'];

                    $kk_new = $gen['id_kelas'] . '_' . $hari_baru . '_' . $jam_baru;
                    if (!empty($used_kelas[$kk_new])) continue;

                    $guru_list = $daftar_guru;
                    shuffle($guru_list);
                    $id_guru_ok = null;
                    foreach ($guru_list as $ig) {
                        $kg_new = $ig . '_' . $hari_baru . '_' . $jam_baru;
                        if (empty($used_guru[$kg_new])) { $id_guru_ok = $ig; break; }
                    }
                    if ($id_guru_ok === null) continue;

                    $ruang_acak = $ruang_ids;
                    shuffle($ruang_acak);
                    $id_ruang_ok = null;
                    foreach ($ruang_acak as $ir) {
                        $kr_new = $ir . '_' . $hari_baru . '_' . $jam_baru;
                        if (empty($used_ruang[$kr_new])) { $id_ruang_ok = $ir; break; }
                    }
                    if ($id_ruang_ok === null) continue;

                    $kromosom[$idx]['hari']    = $hari_baru;
                    $kromosom[$idx]['id_jam']  = $jam_baru;
                    $kromosom[$idx]['id_guru'] = $id_guru_ok;
                    $kromosom[$idx]['id_ruang']= $id_ruang_ok;

                    $used_guru[$id_guru_ok . '_' . $hari_baru . '_' . $jam_baru][]  = $idx;
                    $used_ruang[$id_ruang_ok . '_' . $hari_baru . '_' . $jam_baru][] = $idx;
                    $used_kelas[$kk_new][] = $idx;

                    $found = true;
                    $ada_perbaikan = true;
                    break;
                }
            }

            if (!$found) {
                $used_guru[$kg_old][]  = $idx;
                $used_ruang[$kr_old][] = $idx;
                $used_kelas[$kk_old][] = $idx;
            }
        }

        if (!$ada_perbaikan) break;
    }

    return $kromosom;
}

// =============================================
// 4-7. MULTI-RESTART: ulangi (inisialisasi -> evolusi -> repair) sebanyak
// $num_restart kali, simpan hasil TERBAIK (bentrok paling sedikit) di antara
// semua percobaan. Ini yang mengatasi variasi hasil antar-run yang terjadi
// karena sifat stokastik GA (lihat catatan Versi 8 di atas).
// =============================================
$global_best_kromosom = null;
$global_best_fitness  = -1;
$global_best_generasi = 0;
$global_log_evolusi   = [];
$ringkasan_restart     = []; // untuk laporan: hasil tiap percobaan restart

for ($restart = 1; $restart <= $num_restart; $restart++) {

    // --- 4. Inisialisasi populasi (acak murni) ---
    $populasi = [];
    for ($i = 0; $i < $pop_size; $i++) {
        $populasi[] = buat_kromosom_acak(
            $kelas_ids, $kelas_pelajaran, $guru_mapel, $semua_guru,
            $semua_slot_waktu, $ruang_ids
        );
    }

    // --- 5. Evolusi (dengan logging per generasi) ---
    $best_kromosom = null;
    $best_fitness  = 0;
    $best_generasi = 0;
    $log_evolusi   = [];

    for ($gen = 1; $gen <= $max_gen; $gen++) {

        $fitness_list = array_map('hitung_fitness', $populasi);

        $max_f = max($fitness_list);
        if ($max_f > $best_fitness) {
            $best_fitness  = $max_f;
            $best_generasi = $gen;
            $best_kromosom = $populasi[array_search($max_f, $fitness_list)];
        }

        $log_evolusi[] = [
            'generasi' => $gen,
            'fitness'  => round($max_f, 4),
            'bentrok'  => hitung_bentrok($populasi[array_search($max_f, $fitness_list)]),
        ];

        if ($best_fitness >= 1.0) break;

        $populasi_baru = [$best_kromosom];

        while (count($populasi_baru) < $pop_size) {
            $p1   = seleksi_turnamen($populasi, $fitness_list);
            $p2   = seleksi_turnamen($populasi, $fitness_list);
            $anak = crossover($p1, $p2, $cross_rate);
            $anak = mutasi_smart($anak, $mut_rate, $guru_mapel, $semua_guru, $ruang_ids, $semua_slot_waktu);
            $populasi_baru[] = $anak;
        }

        $populasi = $populasi_baru;
    }

    // --- 6. Repair pasca-evolusi (pembersih sisa bentrok saja) ---
    $bentrok_sebelum_repair = hitung_bentrok($best_kromosom);
    if ($bentrok_sebelum_repair > 0) {
        $best_kromosom = repair_konflik($best_kromosom, $guru_mapel, $semua_guru, $ruang_ids, $semua_slot_waktu);
        $best_fitness  = hitung_fitness($best_kromosom);
    }

    $bentrok_restart_ini = hitung_bentrok($best_kromosom);
    $ringkasan_restart[] = [
        'restart'  => $restart,
        'generasi' => $best_generasi,
        'fitness'  => round($best_fitness, 4),
        'bentrok'  => $bentrok_restart_ini,
    ];

    // Simpan sebagai kandidat global terbaik kalau lebih baik dari sebelumnya
    if ($best_fitness > $global_best_fitness) {
        $global_best_fitness  = $best_fitness;
        $global_best_kromosom = $best_kromosom;
        $global_best_generasi = $best_generasi;
        $global_log_evolusi   = $log_evolusi;
    }

    // Kalau sudah dapat solusi sempurna (0 bentrok), tidak perlu restart lagi
    if ($global_best_fitness >= 1.0) break;
}

$best_kromosom = $global_best_kromosom;
$best_fitness  = $global_best_fitness;
$best_generasi = $global_best_generasi;
$log_evolusi   = $global_log_evolusi;

// =============================================
// 7. HITUNG BENTROK FINAL (AKURAT)
// =============================================
$bentrok_final = hitung_bentrok($best_kromosom);

// =============================================
// 8. SIMPAN KE DATABASE
// =============================================
mysqli_query($conn, "DELETE FROM jadwal WHERE id_semester=$id_semester");

$saved = 0;
foreach ($best_kromosom as $gen) {
    $id_kelas     = (int)$gen['id_kelas'];
    $id_pelajaran = (int)$gen['id_pelajaran'];
    $id_guru      = (int)$gen['id_guru'];
    $id_jam       = (int)$gen['id_jam'];
    $id_ruang     = (int)$gen['id_ruang'];
    $hari         = mysqli_real_escape_string($conn, $gen['hari']);

    $sql = "INSERT INTO jadwal (id_kelas, id_pelajaran, id_guru, id_jam, id_ruang, hari, id_semester)
            VALUES ($id_kelas, $id_pelajaran, $id_guru, $id_jam, $id_ruang, '$hari', $id_semester)";
    if (mysqli_query($conn, $sql)) {
        $saved++;
    } else {
        error_log("GAGAL INSERT jadwal: " . mysqli_error($conn));
    }
}

mysqli_query($conn, "DELETE FROM hasil_ga WHERE id_semester=$id_semester");
mysqli_query($conn, "INSERT INTO hasil_ga (id_semester, generasi, nilai_fitness, status)
    VALUES ($id_semester, $best_generasi, $best_fitness, 'aktif')");

// =============================================
// 8b. SIMPAN LOG PER GENERASI (untuk grafik konvergensi BAB IV)
// =============================================
mysqli_query($conn, "DELETE FROM log_generasi_ga WHERE id_semester=$id_semester");
foreach ($log_evolusi as $lg) {
    $g  = (int)$lg['generasi'];
    $f  = (float)$lg['fitness'];
    $b  = (int)$lg['bentrok'];
    mysqli_query($conn, "INSERT INTO log_generasi_ga (id_semester, generasi, fitness, bentrok)
        VALUES ($id_semester, $g, $f, $b)");
}

// =============================================
// 9. RETURN HASIL
// =============================================
$jumlah_restart_dipakai = count($ringkasan_restart);
$pesan = "Jadwal berhasil dibuat! $saved slot tersimpan. Bentrok: $bentrok_final"
       . " (dipilih dari $jumlah_restart_dipakai percobaan restart)";
if ($bentrok_final > 0) {
    $pesan .= ". Masih ada $bentrok_final bentrok yang tidak bisa diselesaikan otomatis"
            . " — kemungkinan kapasitas slot/guru/ruang tidak cukup untuk menampung"
            . " semua jam_per_minggu yang diminta. Coba cek jumlah jam pelajaran per"
            . " minggu di menu Kurikulum, atau tambah jumlah guru/ruang.";
}

echo json_encode([
    'success'      => true,
    'generasi'     => $best_generasi,
    'fitness'      => $best_fitness,
    'bentrok'      => $bentrok_final,
    'saved'        => $saved,
    'message'      => $pesan,
    'log_evolusi'  => $log_evolusi,
    'ringkasan_restart' => $ringkasan_restart
]);
?>