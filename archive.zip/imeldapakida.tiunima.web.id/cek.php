<?php
$conn = mysqli_connect("127.0.0.1", "jadwaluser", "mRUFvy845a2MKV8ZzDMX", "jadwal");
$result = mysqli_query($conn, "SELECT * FROM users");
while($row = mysqli_fetch_assoc($result)){
    echo $row['username'] . " - " . $row['password'] . "<br>";
}
?>