<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
</head>

<body>
    <br>
    <div class="row">
        <div class="col-3">
            <div class="container">
                <?php include 'menu.php'; ?>
            </div>
        </div>
        <div class="col-9">
            <div class="container">
                <div class="card">
                    <div class="card-body">
                        <h1 class="card-title">Edit Semester</h1>
                    </div>
                </div>
                <br>
                <?php
                $koneksi = mysqli_connect("127.0.0.1", "jadwaluser", "mRUFvy845a2MKV8ZzDMX", "jadwal");
                $id_semester = $_GET['id_semester'];
                $semester = mysqli_query($koneksi, "select * from semester where id_semester='$id_semester'");
                $semester = mysqli_fetch_array($semester);
                ?>
                <form method="post" action="proses_edit_semester.php">
                    <input type="hidden" name="id_semester" value="<?php echo $id_semester; ?>">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Tahun</label>
                        <input type="text" class="form-control" name="tahun" value="<?php echo $semester['tahun']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Semester</label>
                        <select name="semester" id="" class="form-control">
                            <option <?php echo $semester['semester'] == 'ganjil' ? 'selected' : ''; ?> value="ganjil">ganjil</option>
                            <option <?php echo $semester['semester'] == 'genap' ? 'selected' : ''; ?> value="genap">genap</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Edit</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js">
    </script>

    <!-- fungsi datatable -->
    <script>
        $(document).ready(function () {
            $('#table_id').DataTable();
        });

    </script>
</body>

</html>
